/*
  Fontname: -FreeType-fixed_v01-Medium-R-Normal--8-80-72-72-P-51-ISO10646-1
  Copyright: � www.orgdot.com
  Capital A Height: 0, '1' Height: 7
  Calculated Max Values w= 5 h= 7 x= 1 y= 3 dx= 6 dy= 0 ascent= 7 len= 7
  Font Bounding box     w= 7 h= 9 x= 0 y=-2
  Calculated Min Values           x= 0 y= 0 dx= 0 dy= 0
  Pure Font   ascent = 7 descent= 0
  X Font      ascent = 7 descent= 0
  Max Font    ascent = 7 descent= 0
*/
#include "u8g.h"
const u8g_fntpgm_uint8_t u8g_font_fixed_v0n[167] U8G_FONT_SECTION("u8g_font_fixed_v0n") = {
  1,7,9,0,254,7,0,0,0,0,42,58,0,7,0,7,
  0,2,87,103,32,168,112,32,112,168,32,3,85,101,32,32,
  248,32,32,18,34,98,64,128,5,81,97,248,18,18,98,128,
  128,2,87,103,8,16,16,32,64,64,128,2,87,103,112,136,
  136,136,136,136,112,2,87,103,32,96,32,32,32,32,248,2,
  87,103,112,136,8,16,32,64,248,2,87,103,240,8,8,48,
  8,8,240,2,87,103,16,144,144,248,16,16,16,2,87,103,
  248,128,128,240,8,8,240,2,87,103,112,128,128,240,136,136,
  112,2,87,103,248,8,8,8,8,8,8,2,87,103,112,136,
  136,112,136,136,112,2,87,103,112,136,136,248,8,8,112,18,
  21,101,128,128,0,128,128};
