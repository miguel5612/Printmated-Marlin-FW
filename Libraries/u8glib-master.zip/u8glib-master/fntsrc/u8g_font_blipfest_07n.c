/*
  Fontname: -FreeType-Blipfest 07-Medium-R-Normal--8-80-72-72-P-33-ISO10646-1
  Copyright: Copyright cwillmor 2008
  Capital A Height: 0, '1' Height: 5
  Calculated Max Values w= 3 h= 5 x= 0 y= 2 dx= 4 dy= 0 ascent= 5 len= 5
  Font Bounding box     w= 5 h= 6 x= 0 y=-1
  Calculated Min Values           x= 0 y= 0 dx= 0 dy= 0
  Pure Font   ascent = 5 descent= 0
  X Font      ascent = 5 descent= 0
  Max Font    ascent = 5 descent= 0
*/
#include "u8g.h"
const u8g_fntpgm_uint8_t u8g_font_blipfest_07n[169] U8G_FONT_SECTION("u8g_font_blipfest_07n") = {
  0,5,6,0,255,5,0,0,0,0,42,58,0,5,0,5,
  0,255,3,3,3,4,0,1,64,224,64,1,2,2,2,0,
  0,128,128,3,1,1,4,0,2,224,1,1,1,2,0,0,
  128,255,3,5,5,4,0,0,224,160,160,160,224,2,5,5,
  3,0,0,192,64,64,64,64,3,5,5,4,0,0,224,32,
  224,128,224,3,5,5,4,0,0,224,32,224,32,224,3,5,
  5,4,0,0,160,160,224,32,32,3,5,5,4,0,0,224,
  128,224,32,224,3,5,5,4,0,0,224,128,224,160,224,3,
  5,5,4,0,0,224,32,32,32,32,3,5,5,4,0,0,
  224,160,224,160,224,3,5,5,4,0,0,224,160,224,32,224,
  1,3,3,2,0,0,128,0,128};
